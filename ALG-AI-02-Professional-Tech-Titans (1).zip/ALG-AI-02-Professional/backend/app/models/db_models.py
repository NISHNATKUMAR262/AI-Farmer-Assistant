from datetime import datetime
from sqlalchemy import Column, String, Integer, DateTime, Text
from app.core.database import Base

class Document(Base):
    __tablename__ = "documents"
    id = Column(String, primary_key=True)
    filename = Column(String, nullable=False)
    file_type = Column(String, nullable=False)
    pages = Column(Integer, default=0)
    chunks_indexed = Column(Integer, default=0)
    extracted_characters = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

class Investigation(Base):
    __tablename__ = "investigations"
    id = Column(String, primary_key=True)
    question = Column(Text, nullable=False)
    answer = Column(Text, nullable=False)
    uncertainty_level = Column(String, nullable=False)
    uncertainty_score = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

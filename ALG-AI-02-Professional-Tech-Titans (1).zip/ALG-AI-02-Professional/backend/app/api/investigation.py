import uuid
from fastapi import APIRouter,Depends
from sqlalchemy.orm import Session
from app.core.config import settings
from app.core.database import get_db
from app.models.db_models import Investigation
from app.schemas.investigation import InvestigationRequest
from app.services.embeddings import EmbeddingService
from app.services.vector_store import VectorStore
from app.services.retrieval import RetrievalService
from app.services.conflict import ConflictDetector
from app.services.uncertainty import UncertaintyEngine
from app.services.rag import RAGService
router=APIRouter(prefix="/investigate",tags=["Investigation"])
embed=EmbeddingService(); store=VectorStore(); store.load(); retrieval=RetrievalService(); conflicts=ConflictDetector(); uncertainty=UncertaintyEngine(); rag=RAGService()
@router.post("/")
def investigate(req:InvestigationRequest,db:Session=Depends(get_db)):
    candidates=store.search(embed.encode([req.question])[0],min(30,req.top_k*4)); sources=retrieval.rerank(req.question,candidates,req.top_k); found=conflicts.detect(sources,embed); unc=uncertainty.calculate(sources,found); generated=rag.answer(req.question,sources,found,unc)
    db.add(Investigation(id=str(uuid.uuid4()),question=req.question,answer=generated["answer"],uncertainty_level=unc["level"],uncertainty_score=str(unc["score"]))); db.commit()
    return {"success":True,"question":req.question,"answer":generated["answer"],"mode":generated["mode"],"sources":sources,"conflicts":found,"uncertainty":unc}

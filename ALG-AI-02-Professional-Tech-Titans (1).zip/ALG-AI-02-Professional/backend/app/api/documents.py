import uuid
from pathlib import Path
from fastapi import APIRouter,UploadFile,File,HTTPException,Depends
from sqlalchemy.orm import Session
from app.core.config import settings
from app.core.database import get_db
from app.models.db_models import Document
from app.services.extraction import DocumentExtractor
from app.services.chunking import TextChunker
from app.services.embeddings import EmbeddingService
from app.services.vector_store import VectorStore
router=APIRouter(prefix="/documents",tags=["Documents"])
ALLOWED={".pdf",".docx",".pptx",".txt",".png",".jpg",".jpeg"}
embed=EmbeddingService(); store=VectorStore(); store.load(); chunker=TextChunker()
@router.post("/upload")
async def upload(file:UploadFile=File(...),db:Session=Depends(get_db)):
    if not file.filename: raise HTTPException(400,"Filename is required")
    ext=Path(file.filename).suffix.lower()
    if ext not in ALLOWED: raise HTTPException(400,"Unsupported file format")
    content=await file.read()
    if len(content)>settings.MAX_FILE_SIZE_MB*1024*1024: raise HTTPException(413,"File too large")
    doc_id=str(uuid.uuid4()); up=Path(settings.UPLOAD_DIR); ex=Path(settings.EXTRACTED_DIR); up.mkdir(parents=True,exist_ok=True); ex.mkdir(parents=True,exist_ok=True)
    path=up/f"{doc_id}{ext}"; path.write_bytes(content)
    try:
        pages=DocumentExtractor.extract(str(path)); chunks=chunker.chunk(pages,doc_id,file.filename)
        if chunks: store.add(embed.encode([c["text"] for c in chunks]),chunks)
    except Exception as e: raise HTTPException(500,f"Processing failed: {e}")
    extracted="\n\n".join(f"--- Page/Slide {p['page']} ---\n{p['text']}" for p in pages if p["text"])
    (ex/f"{doc_id}.txt").write_text(extracted,encoding="utf-8")
    db.add(Document(id=doc_id,filename=file.filename,file_type=ext,pages=len(pages),chunks_indexed=len(chunks),extracted_characters=len(extracted))); db.commit()
    return {"success":True,"document_id":doc_id,"filename":file.filename,"pages":len(pages),"chunks_indexed":len(chunks),"status":"processed"}
@router.get("/")
def documents(db:Session=Depends(get_db)):
    return [{"document_id":d.id,"filename":d.filename,"pages":d.pages,"chunks_indexed":d.chunks_indexed,"created_at":d.created_at.isoformat()} for d in db.query(Document).order_by(Document.created_at.desc()).all()]

from fastapi import APIRouter,Depends
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.db_models import Investigation
router=APIRouter(prefix="/history",tags=["History"])
@router.get("/")
def history(db:Session=Depends(get_db)):
    return [{"id":x.id,"question":x.question,"answer":x.answer,"uncertainty_level":x.uncertainty_level,"created_at":x.created_at.isoformat()} for x in db.query(Investigation).order_by(Investigation.created_at.desc()).limit(50).all()]

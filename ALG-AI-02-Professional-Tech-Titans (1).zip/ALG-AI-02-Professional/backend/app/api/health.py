from fastapi import APIRouter
router=APIRouter(tags=["Health"])
@router.get("/health")
def health(): return {"status":"healthy","problem_id":"ALG-AI-02","version":"2.0.0"}

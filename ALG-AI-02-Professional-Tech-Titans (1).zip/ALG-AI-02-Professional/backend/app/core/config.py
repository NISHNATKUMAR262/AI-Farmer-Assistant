from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    APP_NAME: str = "AI Intelligent Document Investigator"
    APP_VERSION: str = "2.0.0"
    UPLOAD_DIR: str = "data/uploads"
    EXTRACTED_DIR: str = "data/extracted"
    VECTOR_DB_DIR: str = "data/vector_db"
    DATABASE_URL: str = "sqlite:///./data/investigator.db"
    EMBEDDING_MODEL: str = "all-MiniLM-L6-v2"
    TOP_K: int = 8
    MAX_FILE_SIZE_MB: int = 50
    CHUNK_WORDS: int = 220
    OVERLAP_WORDS: int = 45
    OPENAI_API_KEY: str = ""
    LLM_MODEL: str = "gpt-5.6"
    TESSERACT_CMD: str = ""
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()

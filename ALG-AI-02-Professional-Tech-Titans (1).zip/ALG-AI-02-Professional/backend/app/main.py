from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.core.database import init_db
from app.api.health import router as health
from app.api.documents import router as documents
from app.api.investigation import router as investigation
from app.api.history import router as history
for d in [settings.UPLOAD_DIR,settings.EXTRACTED_DIR,settings.VECTOR_DB_DIR]: Path(d).mkdir(parents=True,exist_ok=True)
init_db()
app=FastAPI(title=settings.APP_NAME,version=settings.APP_VERSION,description="Source-grounded AI document investigation platform")
app.add_middleware(CORSMiddleware,allow_origins=["http://localhost:5173","http://127.0.0.1:5173"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
app.include_router(health); app.include_router(documents); app.include_router(investigation); app.include_router(history)
@app.get("/")
def root(): return {"project":settings.APP_NAME,"problem_id":"ALG-AI-02","team":"Tech Titans","members":["Nishant Kumar","Yuckti Goyal"],"docs":"/docs"}

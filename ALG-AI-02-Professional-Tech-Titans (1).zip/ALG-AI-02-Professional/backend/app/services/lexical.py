import re
from collections import Counter

def lexical_score(query,text):
    q=Counter(re.findall(r"[a-zA-Z0-9]{2,}",query.lower())); t=Counter(re.findall(r"[a-zA-Z0-9]{2,}",text.lower()))
    if not q:return 0.0
    return sum(min(q[k],t.get(k,0)) for k in q)/sum(q.values())

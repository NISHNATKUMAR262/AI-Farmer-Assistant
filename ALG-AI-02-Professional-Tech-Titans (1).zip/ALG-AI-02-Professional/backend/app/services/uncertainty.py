class UncertaintyEngine:
    def calculate(self,sources,conflicts):
        if not sources:return {"level":"HIGH","score":1.0,"reason":"No supporting evidence found."}
        avg=sum(s.get("score",0) for s in sources)/len(sources); score=max(0,min(1,(1-avg)+min(.6,len(conflicts)*.15)))
        level="LOW" if score<.25 else "MEDIUM" if score<.55 else "HIGH"
        return {"level":level,"score":round(score,3),"reason":"Conflicting evidence was detected." if conflicts else "Based on retrieval strength and evidence coverage."}

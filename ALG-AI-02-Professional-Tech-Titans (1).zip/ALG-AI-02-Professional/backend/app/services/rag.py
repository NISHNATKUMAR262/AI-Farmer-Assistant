from openai import OpenAI
from app.core.config import settings

class RAGService:
    def __init__(self): self.client=OpenAI(api_key=settings.OPENAI_API_KEY) if settings.OPENAI_API_KEY else None
    def answer(self,question,sources,conflicts,uncertainty):
        if not self.client:return {"mode":"retrieval_only","answer":"LLM key is not configured. Evidence was retrieved successfully. Configure OPENAI_API_KEY for a generated investigation answer."}
        evidence="\n\n".join(f"[Source {i}] {s['document']} — page/slide {s['page']}\n{s['text']}" for i,s in enumerate(sources,1))
        conflict_text="\n".join(f"- {c['source_a']['document']} p.{c['source_a']['page']} vs {c['source_b']['document']} p.{c['source_b']['page']}: {c['reason']}" for c in conflicts) or "No explicit conflict detected."
        prompt=f'''You are a professional source-grounded document investigator.\nQUESTION:\n{question}\n\nEVIDENCE:\n{evidence}\n\nCONFLICTS:\n{conflict_text}\n\nUNCERTAINTY:\n{uncertainty}\n\nRules: use only supplied evidence; never invent facts; cite important claims as [Source N]; mention page/slide; show both sides of disagreements; state when evidence is insufficient; separate confirmed facts from inference. Return Answer, Key Evidence, Conflicts, and Uncertainty.'''
        r=self.client.chat.completions.create(model=settings.LLM_MODEL,temperature=0,messages=[{"role":"system","content":"You are a precise document investigator."},{"role":"user","content":prompt}])
        return {"mode":"llm_rag","answer":r.choices[0].message.content}

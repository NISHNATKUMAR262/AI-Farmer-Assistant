from pathlib import Path
import json, faiss, numpy as np
from app.core.config import settings

class VectorStore:
    def __init__(self):
        self.index=None; self.metadata=[]
        Path(settings.VECTOR_DB_DIR).mkdir(parents=True,exist_ok=True)
    def load(self):
        ip=Path(settings.VECTOR_DB_DIR)/"index.faiss"; mp=Path(settings.VECTOR_DB_DIR)/"metadata.json"
        if ip.exists() and mp.exists(): self.index=faiss.read_index(str(ip)); self.metadata=json.loads(mp.read_text(encoding="utf-8"))
    def add(self,embeddings,metadata):
        if not len(embeddings): return
        vectors=np.asarray(embeddings,dtype="float32")
        if self.index is None: self.index=faiss.IndexFlatIP(vectors.shape[1])
        self.index.add(vectors); self.metadata.extend(metadata); self.save()
    def save(self):
        if self.index is None:return
        faiss.write_index(self.index,str(Path(settings.VECTOR_DB_DIR)/"index.faiss"))
        (Path(settings.VECTOR_DB_DIR)/"metadata.json").write_text(json.dumps(self.metadata,ensure_ascii=False,indent=2),encoding="utf-8")
    def search(self,q,k=8):
        if self.index is None or self.index.ntotal==0:return []
        scores,ids=self.index.search(np.asarray([q],dtype="float32"),min(k,self.index.ntotal)); out=[]
        for score,idx in zip(scores[0],ids[0]):
            item=self.metadata[int(idx)].copy(); item["semantic_score"]=float(score); out.append(item)
        return out

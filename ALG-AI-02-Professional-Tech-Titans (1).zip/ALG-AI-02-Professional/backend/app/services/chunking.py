import re
from app.core.config import settings

class TextChunker:
    def chunk(self, pages, document_id, document_name):
        result=[]
        for page in pages:
            text=re.sub(r"\s+"," ",page["text"]).strip()
            if not text: continue
            words=text.split(); start=0
            while start<len(words):
                end=min(start+settings.CHUNK_WORDS,len(words))
                result.append({"chunk_id":f"{document_id}-{len(result)}","document_id":document_id,"document":document_name,"page":page["page"],"text":" ".join(words[start:end])})
                if end==len(words): break
                start=end-settings.OVERLAP_WORDS
        return result

from sentence_transformers import SentenceTransformer
from app.core.config import settings

class EmbeddingService:
    def __init__(self): self.model=SentenceTransformer(settings.EMBEDDING_MODEL)
    def encode(self,texts): return self.model.encode(texts,normalize_embeddings=True,show_progress_bar=False)

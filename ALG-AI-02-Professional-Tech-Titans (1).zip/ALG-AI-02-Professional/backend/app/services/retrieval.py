from app.services.lexical import lexical_score
class RetrievalService:
    def rerank(self,query,candidates,limit):
        for x in candidates:
            semantic=max(0,min(1,(x.get("semantic_score",0)+1)/2)); lexical=lexical_score(query,x["text"])
            x["score"]=round(.75*semantic+.25*lexical,4)
        return sorted(candidates,key=lambda x:x["score"],reverse=True)[:limit]

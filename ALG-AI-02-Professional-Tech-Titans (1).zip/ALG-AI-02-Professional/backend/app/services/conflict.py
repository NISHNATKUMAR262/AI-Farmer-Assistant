import re
from sklearn.metrics.pairwise import cosine_similarity
class ConflictDetector:
    def detect(self,sources,embedding_service):
        conflicts=[]
        if len(sources)<2:return conflicts
        em=embedding_service.encode([s["text"] for s in sources])
        for i in range(len(sources)):
            for j in range(i+1,len(sources)):
                sim=float(cosine_similarity([em[i]],[em[j]])[0][0])
                a=set(re.findall(r"\b\d+(?:\.\d+)?%?\b",sources[i]["text"])); b=set(re.findall(r"\b\d+(?:\.\d+)?%?\b",sources[j]["text"]))
                if sim>=.45 and a and b and a!=b:
                    conflicts.append({"type":"possible_numeric_conflict","similarity":round(sim,3),"source_a":sources[i],"source_b":sources[j],"reason":"Semantically related evidence contains different numeric values."})
        return conflicts

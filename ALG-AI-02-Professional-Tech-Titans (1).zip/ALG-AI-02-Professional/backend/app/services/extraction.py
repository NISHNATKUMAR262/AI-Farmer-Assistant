from pathlib import Path
import fitz
from docx import Document
from pptx import Presentation
from PIL import Image
import pytesseract
from app.core.config import settings

class DocumentExtractor:
    @staticmethod
    def ocr_image(path: str) -> str:
        if settings.TESSERACT_CMD:
            pytesseract.pytesseract.tesseract_cmd = settings.TESSERACT_CMD
        with Image.open(path) as image:
            return pytesseract.image_to_string(image).strip()

    @classmethod
    def extract_pdf(cls, path: str):
        pages = []
        doc = fitz.open(path)
        for n, page in enumerate(doc, 1):
            text = page.get_text("text").strip()
            if len(text) < 30:
                pix = page.get_pixmap(matrix=fitz.Matrix(1.7, 1.7), alpha=False)
                tmp = Path(path).with_name(f"{Path(path).stem}_page_{n}.png")
                pix.save(str(tmp))
                try: text = cls.ocr_image(str(tmp))
                finally: tmp.unlink(missing_ok=True)
            pages.append({"page": n, "text": text})
        doc.close()
        return pages

    @staticmethod
    def extract_docx(path: str):
        doc = Document(path)
        return [{"page": 1, "text": "\n".join(p.text.strip() for p in doc.paragraphs if p.text.strip())}]

    @staticmethod
    def extract_pptx(path: str):
        prs = Presentation(path); result=[]
        for n, slide in enumerate(prs.slides, 1):
            texts=[shape.text.strip() for shape in slide.shapes if hasattr(shape,"text") and shape.text.strip()]
            result.append({"page":n,"text":"\n".join(texts)})
        return result

    @staticmethod
    def extract_txt(path: str):
        return [{"page":1,"text":Path(path).read_text(encoding="utf-8",errors="ignore")}]

    @classmethod
    def extract(cls, path: str):
        ext=Path(path).suffix.lower()
        if ext==".pdf": return cls.extract_pdf(path)
        if ext==".docx": return cls.extract_docx(path)
        if ext==".pptx": return cls.extract_pptx(path)
        if ext==".txt": return cls.extract_txt(path)
        if ext in {".png",".jpg",".jpeg"}: return [{"page":1,"text":cls.ocr_image(path)}]
        raise ValueError(f"Unsupported format: {ext}")
